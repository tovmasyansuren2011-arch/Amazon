# Shuka verification — 19 November 2026

## Passed

- Production build: Vite successfully generated the frontend.
- API acceptance suite: 12 tests passed, including all nine required break-it scenarios.
- Last units: 30 simultaneous HTTP checkouts against stock 3 produced exactly 3 successful orders and 27 HTTP 409 responses; final stock 0.
- Duplicate request key: one order and one deduction.
- Price conflict: checkout blocked and new price reported.
- Historical snapshots: old title and purchase price preserved after editing.
- Authorization: foreign buyer and seller details and mutations rejected.
- Lifecycle: skipped transitions and cancellation after shipping rejected.
- Cancellation: stock restored once; repeat cancellation rejected.
- SQLite: foreign keys and STRICT type validation enforced.
- Uploads: 30 MB and fake-image executable payloads rejected; valid image resized, thumbnail created.
- Additional API checks: multi-seller totals, delivered-only unique reviews, rating/revenue update, guest/self-purchase denial, transaction rollback on a later stock failure.
- Desktop browser: keyword search, sign in, add to bag, checkout, order confirmation; no JavaScript page exceptions.
- Seller browser: registration, store activation, product creation with three images, publication, editor gallery.
- Mobile browser at 390 × 844: two-seller cart, quantity change, delivery form, order detail, seller lifecycle, delivered review. No horizontal page overflow on home, catalog or order detail.
- Final homepage visual checks: desktop and mobile screenshots inspected; all bundled images loaded successfully.
- Database backup: the backup command completed successfully.

## Not verified / pending

- Public HTTPS deployment: needs a compatible host with a persistent disk.
- Data retention after a real production redeploy.
- Scheduled daily backups and off-host retention.
- Physical phone testing; mobile checks used Chromium device emulation.

## Re-run

`npm test` runs isolated API tests against a temporary seeded database.

Start the production build locally (`npm run build && npm start`), then run the browser scripts in `scripts/`. Install a matching Chromium with `npx playwright install chromium`, or set `CHROMIUM_PATH` to an installed executable. Browser scripts mutate the local demo database and are intended for a disposable evaluation instance.

## Expanded catalog verification

Added 72 demo products, giving 114 published demo listings across six categories. The expansion is repeat-safe (a second run inserts zero rows). All six first category pages rendered 12 cards with loaded images; Books & Gifts includes eight named classics with custom illustrated covers. Laptop search returned the two relevant new listings. The mobile catalog had no horizontal overflow. All 12 API acceptance tests still passed after the seed update.
