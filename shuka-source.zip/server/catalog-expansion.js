// Demo merchandise, grouped by category. Prices and availability are sample data.
const catalog={
'Electronics':[
 ['Everyday notebook laptop',249000,'laptop','A compact notebook computer for studying, browsing and everyday office work. Includes a charging adapter.'],
 ['Touchscreen smartphone',139000,'phone','A pocket-size touchscreen phone for messages, photographs and everyday apps. Includes a USB charging cable.'],
 ['Compact wireless keyboard',18900,'keyboard','A low-profile keyboard with a compact layout for a tidy desk. A practical addition to your home office.'],
 ['Portable Bluetooth speaker',24900,'speaker','A portable wireless speaker for listening at home or taking music along. Includes a charging cable.'],
 ['Wireless everyday mouse',11900,'mouse','A compact wireless mouse with a scroll wheel and comfortable shape for everyday desktop work.'],
 ['Touchscreen tablet',169000,'tablet','A portable tablet for reading, video calls and entertainment. A charging adapter is included.'],
 ['Home office laptop',319000,'laptop','A notebook computer for your everyday workspace, with a full-size screen and portable design.'],
 ['Study desk keyboard',22500,'keyboard','A slim keyboard for typing assignments, emails and notes. Easy to position on smaller desks.'],
 ['Travel Bluetooth speaker',29900,'speaker','A compact speaker with a carry-friendly shape for music around the house or on a weekend trip.'],
 ['Wireless desk mouse',14500,'mouse','A wireless mouse for an uncluttered desktop. Suitable for everyday browsing and document work.'],
 ['Reading & media tablet',129000,'tablet','A touchscreen tablet for digital books, browsing and watching videos. Lightweight enough to take along.'],
 ['Pocket smartphone',119000,'phone','A touchscreen smartphone for everyday calls, messages and photos, supplied with a charging cable.']
],
'Home & Living':[
 ['Upholstered dining chair',38900,'chair','A fabric-covered dining chair with wooden legs. A comfortable seat for the dining table or a reading corner.'],
 ['Adjustable desk lamp',14900,'lamp','A classic metal desk lamp with an adjustable shade to direct light onto books, notes or your workspace.'],
 ['Three-seat fabric sofa',219000,'sofa','A fabric sofa with a generous seat and slender legs. A welcoming centerpiece for a living room.'],
 ['Potted tabletop succulent',4900,'plant','A small succulent in a decorative pot for your desk or windowsill. Place in bright light and water sparingly.'],
 ['Everyday ceramic mug',3500,'mug','A simple ceramic mug for tea, coffee or hot chocolate. A comfortable handle makes it an everyday favorite.'],
 ['Soft bedroom pillow',7900,'cushion','A soft filled pillow in a light-colored cover. A simple addition to a restful bedroom.'],
 ['Reading corner chair',44900,'chair','A fabric accent chair with wooden legs, sized for a cozy reading nook or bedroom corner.'],
 ['Bedside reading lamp',12900,'lamp','An adjustable-shade lamp to bring focused light to a bedside table or quiet reading spot.'],
 ['Living room fabric sofa',239000,'sofa','An upholstered sofa for relaxed evenings and family gatherings. Raised legs make cleaning beneath easier.'],
 ['Desk succulent planter',5900,'plant','A compact succulent and decorative pot, ready to add a little greenery to your workday.'],
 ['Ceramic mug pair',6500,'mug','Two simple ceramic mugs for slow mornings together. Matching everyday shapes with easy-grip handles.'],
 ['Bedroom pillow pair',13900,'cushion','A set of two soft filled pillows for refreshing your bed. Supplied in light-colored covers.']
],
'Fashion':[
 ['Everyday cotton T-shirt',6900,'tshirt','A plain short-sleeve cotton T-shirt with a crew neck. A simple starting point for an everyday wardrobe.'],
 ['Utility overshirt jacket',24900,'jacket','A relaxed utility-style outer layer with pockets and an easy everyday fit. Wear over a T-shirt or knit.'],
 ['Classic denim jeans',16900,'jeans','Everyday denim jeans with a familiar five-pocket design. An easy foundation for casual outfits.'],
 ['Round-frame sunglasses',9900,'sunglasses','Round lenses and a slim frame for a relaxed everyday look. Supplied with a protective pouch.'],
 ['Daily commuter backpack',18900,'bag','A zip-up backpack for carrying your workday essentials. Adjustable shoulder straps keep it comfortable on the go.'],
 ['Floral occasion heels',27900,'boots','Bright floral-patterned high heels for celebrations and special evenings. A colorful statement pair.'],
 ['Cotton essentials T-shirt',7900,'tshirt','A plain crew-neck tee for comfortable, uncomplicated dressing. Short sleeves and a clean silhouette.'],
 ['Weekend utility jacket',29900,'jacket','An easy layered jacket with a utility-inspired shape and practical pockets for everyday essentials.'],
 ['Everyday denim trousers',18900,'jeans','Casual denim trousers made for regular rotation, with belt loops and practical front and back pockets.'],
 ['Metal-frame sunglasses',12900,'sunglasses','A lightweight-looking metal frame and round lenses, with a storage pouch for your bag.'],
 ['Campus day backpack',22900,'bag','A practical backpack for books, stationery and the things you carry each day. Features zippered compartments.'],
 ['Printed party heels',31900,'boots','A floral-print high-heel pair to dress up a simple outfit for a party or special occasion.']
],
'Beauty & Care':[
 ['Daily facial toner',7900,'skincare','A facial toner for a simple daily skincare routine. Read the packaging directions and patch-test before use.'],
 ['Facial care serum',11900,'serum','A lightweight facial serum in a dropper bottle for your daily care routine. Follow the label instructions.'],
 ['Everyday skincare duo',16900,'soap','A two-piece facial care set for a straightforward routine. Supplied in the original product packaging.'],
 ['Everyday makeup collection',21900,'makeup','A coordinated selection of everyday makeup essentials for a simple getting-ready routine.'],
 ['Eyeshadow palette & beauty set',24900,'brushes','A makeup set centered on a multi-shade eyeshadow palette, with complementary beauty essentials.'],
 ['Botanical facial oil',14900,'serum','A facial care oil in a dropper bottle. Use according to the label and test on a small area first.'],
 ['Evening facial toner',8900,'skincare','A facial toner for your evening cleansing routine. Check the ingredient label for your individual needs.'],
 ['Skincare essentials set',18900,'soap','A paired skincare set in a presentation box. A practical addition to a daily bathroom routine.'],
 ['Getting-ready makeup kit',26900,'makeup','A selection of makeup essentials for experimenting with an everyday look. Keep tools clean between uses.'],
 ['Makeup palette collection',28900,'brushes','A multi-shade palette and complementary makeup items for creating different looks.'],
 ['Daily face serum',13900,'serum','A facial serum supplied in a glass dropper bottle. Apply only as directed on its packaging.'],
 ['Gentle skincare gift duo',19900,'soap','A packaged two-item skincare selection, ready to give as a thoughtful personal-care gift.']
],
'Sports & Outdoors':[
 ['Exercise hand-weight pair',9900,'dumbbell','A pair of compact hand weights for controlled home workouts. Start with a comfortable load and good form.'],
 ['Court basketball',12900,'basketball','A basketball for practice sessions and casual games at the local court. Inflate before play as directed.'],
 ['Everyday football',8900,'football','A football for park games and regular practice. A simple addition to your sports bag.'],
 ['City commuter bicycle',149000,'bicycle','A city-style bicycle for everyday rides. Check fit, brakes and tire pressure before riding.'],
 ['Home yoga mat',11900,'yoga','A roll-up exercise mat for stretching, yoga and floor work. Lay it on an even surface before use.'],
 ['Sports day backpack',16900,'bag','A zip-up backpack for carrying a change of clothes and your everyday sports essentials.'],
 ['Home workout weights',14900,'dumbbell','A pair of hand weights for adding resistance to controlled exercise. Suitable for a compact home workout space.'],
 ['Training basketball',14900,'basketball','A basketball for practicing passing, dribbling and shooting. Designed for regular recreational play.'],
 ['Weekend practice football',10900,'football','A football for an afternoon kickabout or training drills. Store dry after use.'],
 ['Urban leisure bicycle',179000,'bicycle','A city-style bicycle for relaxed rides around the neighborhood. Have the fit and setup checked before use.'],
 ['Stretching & exercise mat',13900,'yoga','A portable mat for stretching and floor exercises at home. Roll up for storage after your session.'],
 ['Outdoor day backpack',19900,'bag','A practical daypack for a short outing, with zippered storage and adjustable shoulder straps.']
],
'Books & Gifts':[
 ['Pride and Prejudice — Jane Austen',6900,'book-pride','Jane Austen’s classic novel of first impressions, family expectations and the relationship between Elizabeth Bennet and Mr. Darcy. English-language paperback.'],
 ['The Adventures of Sherlock Holmes',7900,'book-sherlock','Arthur Conan Doyle’s collection of mysteries featuring Sherlock Holmes and Dr. Watson. English-language paperback.'],
 ['Alice’s Adventures in Wonderland',5900,'book-alice','Lewis Carroll’s imaginative journey through Wonderland, with Alice, the White Rabbit and a world of curious characters. English-language paperback.'],
 ['Little Women — Louisa May Alcott',7500,'book-little','The story of the four March sisters as they grow up, follow their ambitions and care for one another. English-language paperback.'],
 ['The Secret Garden — Frances Hodgson Burnett',6500,'book-garden','A classic story of friendship, discovery and a forgotten garden brought back to life. English-language paperback.'],
 ['Treasure Island — Robert Louis Stevenson',6500,'book-treasure','Jim Hawkins sets out on a seafaring adventure with a treasure map and a dangerous crew. English-language paperback.'],
 ['A Tale of Two Cities — Charles Dickens',7900,'book-cities','Charles Dickens’s historical novel set in London and Paris during the French Revolution. English-language paperback.'],
 ['The Wonderful Wizard of Oz',5900,'book-oz','L. Frank Baum’s classic adventure follows Dorothy and her companions along the yellow brick road. English-language paperback.'],
 ['Everyday writing notebook',3900,'notebook','A spiral-bound notebook for ideas, study notes and daily lists. A useful small gift for a new project.'],
 ['Classic chess set',14900,'chess','A chess board and contrasting pieces for a quiet game together. A thoughtful gift for a strategy-game enthusiast.'],
 ['Notebook & writing gift set',6900,'notebook','A notebook and pen pairing for a friend who loves writing, journaling or making plans.'],
 ['Chess night gift set',18900,'chess','A classic chess set for bringing people around a board. Includes a full set of pieces and a playing board.']
]};
export function expandCatalog(db){
 const sellers=db.prepare("SELECT id FROM users WHERE email IN ('seller1@shuka.am','seller2@shuka.am','seller3@shuka.am') ORDER BY id").all();if(sellers.length!==3)return;
 const categories=db.prepare('SELECT id,name FROM categories').all();let added=0;
 db.transaction(()=>{for(let row=0;row<12;row++)for(const [name,entries]of Object.entries(catalog)){
 const category=categories.find(c=>c.name===name);if(!category)continue;const [title,price,image,description]=entries[row];const seller=sellers[(row+category.id)%3].id;
 if(db.prepare('SELECT 1 FROM products WHERE title=? AND seller_id=?').get(title,seller))continue;
 const id=Number(db.prepare('INSERT INTO products(seller_id,category_id,title,description,price_amd,stock,is_published) VALUES(?,?,?,?,?,?,1)').run(seller,category.id,title,description+' Delivery within Armenia. Pay in cash on arrival.',price,9+(row*3+category.id)%22).lastInsertRowid);
 db.prepare('INSERT INTO product_images(product_id,file_path,position) VALUES(?,?,0)').run(id,`/images/catalog/${image}.${image.startsWith('book-')?'svg':'jpg'}`);added++;
 }
 // Correct original demo listings only when both their title and original image still match.
 const fixes=[
 ['Everyday canvas backpack','Everyday canvas backpack',3,'bag'],['City daypack','City daypack',3,'bag'],['Weekend travel backpack','Weekend travel backpack',3,'bag'],
 ['Canvas book bag','Canvas book tote',3,null],['Instant photo camera','Instant photo camera',1,null],['Modern art gift','Modern wall art print',2,null],
 ['Armenian coffee gift set','Ceramic coffee mug gift',6,'mug'],['Morning ritual gift box','Coffee mug gift pair',6,'mug'],['Slow morning coffee set','Morning ceramic mug pair',2,'mug'],['Ceramic coffee collection','Ceramic coffee mug collection',2,'mug']
 ];
 for(const [old,title,cat,image]of fixes){const matches=db.prepare("SELECT p.id FROM products p JOIN product_images i ON i.product_id=p.id AND i.position=0 WHERE p.title=? AND p.seller_id IN (?,?,?) AND i.file_path LIKE '/images/photo-%'").all(old,...sellers.map(s=>s.id));for(const p of matches){db.prepare('UPDATE products SET title=?,category_id=? WHERE id=?').run(title,cat,p.id);if(image)db.prepare('UPDATE product_images SET file_path=? WHERE product_id=? AND position=0').run(`/images/catalog/${image}.jpg`,p.id);}}
 }).immediate();return added;
}
