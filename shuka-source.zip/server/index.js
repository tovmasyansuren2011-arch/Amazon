import path from 'node:path';
import {openDatabase} from './db.js';
import {createApp} from './app.js';
import {seed} from './seed.js';
const dir=path.resolve(process.env.DATA_DIR||'data');
if(process.env.NODE_ENV==='production'&&(!process.env.SESSION_SECRET||process.env.SESSION_SECRET.length<32))throw new Error('Set SESSION_SECRET to at least 32 random characters');
const db=openDatabase(path.join(dir,'shuka.sqlite'));
if(process.env.SEED_DEMO==='true'||process.env.NODE_ENV!=='production')await seed(db);
createApp(db,{uploads:path.join(dir,'uploads'),secret:process.env.SESSION_SECRET,production:process.env.NODE_ENV==='production'}).listen(process.env.PORT||3000,'0.0.0.0',()=>console.log('Shuka running on port '+(process.env.PORT||3000)));
