import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
export function openDatabase(file){
 fs.mkdirSync(path.dirname(file),{recursive:true});
 const db=new Database(file);db.pragma('journal_mode = WAL');db.pragma('foreign_keys = ON');db.pragma('busy_timeout = 5000');
 const version=db.pragma('user_version',{simple:true});
 if(version<1) db.transaction(()=>{db.exec(fs.readFileSync(new URL('./migrations/001_initial.sql',import.meta.url),'utf8'));db.pragma('user_version = 1');}).immediate();
 return db;
}
