# Implementation and acceptance map

Source: all 11 pages of the supplied Shuka brief. The pasted foundation-only prompt was quoted guidance; the direct request asked for the complete website.

## Required architecture

One Node server serves the built React frontend, REST JSON API, uploaded images, and one SQLite file. Ten STRICT domain tables: users, categories, products, product_images, cart_items, orders, seller_orders, order_items, status_history, reviews. Prices are integer AMD, dates ISO-8601, booleans 0/1. Foreign keys, WAL, busy timeout, numbered migration and repeat-safe seed are enabled.

## Phases and verifiable gates

1. Foundation: Vite build succeeds; GET /api/health returns ok; migration creates all tables.
2. Accounts: register/login/logout/profile and immediate seller activation; hashed passwords, HTTP-only cookies, guest denial and ownership protection.
3. Catalog: 114 seeded products, three sellers, two buyers, six flat categories; keyword/category/price search, URL filters, sorting and pagination; product detail, gallery, stock, reviews; seller CRUD without hard deletion and validated image uploads.
4. Purchasing: persistent cart grouped by seller, stock limits and own-product denial; address form with Armenian regions and previous address; COD checkout, request UUID, price-change conflict, seller splitting, snapshots and atomic stock deduction.
5. Lifecycle: placed → confirmed → shipped → delivered, or cancellation from placed/confirmed; server permission checks, insert-only history, atomic stock restoration, delivered-only unique reviews and 30-day seller revenue.
6. Validation: nine specified break-it scenarios plus split-order/review workflow, guest/self-purchase, and atomic rollback; browser buyer flow and responsive layout checks.
7. Production: Dockerfile, persistent-volume environment configuration and SQLite backup command provided. Public HTTPS deployment, scheduled backup execution, restart/durability check and live teacher demo require a compatible hosting account and remain unverified.

## REST API

All brief endpoints are implemented with `/api` prefix. Errors use `{error:{code,message}}` and HTTP 400/401/403/404/409. Auth: POST /auth/register, /auth/login, /auth/logout; GET/PATCH /me. Catalog: GET /categories, /products, /products/:id, /products/:id/reviews. Cart: GET /cart; PUT/DELETE /cart/items/:id. Buyer: POST/GET /orders, GET /orders/:id, POST /orders/:id/sellers/:sid/cancel. Review: POST /products/:id/reviews. Seller: POST /seller/activate, GET /seller/overview; GET/POST /seller/products, PATCH /seller/products/:id, POST/DELETE /seller/products/:id/images; GET /seller/orders, /seller/orders/:id; POST /seller/orders/:id/status.

Image DELETE uses `?imageId=`. Upload uses multipart `images`. The first photo is the main image. A new product starts unpublished until a valid photo is uploaded.

## Important limits

No production URL exists yet. Demo accounts are intentionally shared evaluation credentials. Sessions are in memory and expire on restart; marketplace data persists on disk. Automatic daily backup scheduling must be configured on the production host. Product editor validation combines native field constraints with inline server error feedback. No optional out-of-scope marketplace features were added.
