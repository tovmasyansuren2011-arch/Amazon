import {spawn} from 'node:child_process';
const children=[spawn('node',['--watch','server/index.js'],{stdio:'inherit'}),spawn('npx',['vite'],{stdio:'inherit'})];
for(const s of ['SIGINT','SIGTERM'])process.on(s,()=>{children.forEach(c=>c.kill(s));process.exit();});
