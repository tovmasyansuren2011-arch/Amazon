# Shuka — your local marketplace

A responsive React marketplace for Armenia, backed by Express and a real SQLite database. All prices are integer AMD; payment is cash on delivery.

## Run locally

Node.js 22.12+ is required. From this directory run:

```sh
npm install && npm run dev
```

Open http://localhost:5173. Vite forwards the API to Express on port 3000. Development seeds three sellers, two buyers, six categories and 114 products automatically on an empty database.

Demo accounts: `seller1@shuka.am`, `seller2@shuka.am`, `seller3@shuka.am`, `buyer1@shuka.am`, `buyer2@shuka.am`. Password: `ShukaDemo2026!`. Use only for evaluation; do not seed shared demo credentials into a real commercial service.

```sh
npm test
npm run build
npm start
```

The production build is served by the same Express process at http://localhost:3000.

## Architecture

- `src/main.jsx`: storefront, catalog, product detail, account, cart, checkout, buyer order history, seller activation, dashboard, product editor and incoming orders.
- `src/style.css`: responsive design system using Tailwind's build integration and custom component CSS.
- `server/app.js`: REST routes under `/api`, authentication, ownership checks, image handling and transaction boundaries.
- `server/db.js` and `server/migrations/001_initial.sql`: numbered SQL migration, STRICT tables, foreign keys, WAL and 5-second busy timeout. Migration level uses SQLite `user_version` without an extra domain table.
- `server/seed.js`: repeat-safe initial demo data.
- `tests/acceptance.test.js`: all nine required break-it scenarios plus workflow tests.

Checkout uses `BEGIN IMMEDIATE` through better-sqlite3's immediate transaction method. Stock is conditionally decremented and the entire transaction rolls back on any conflict. The request key is unique, buyer identity is checked before returning an existing order, seller orders split totals, and order items preserve titles and prices. Cancelling restores stock inside the same transaction and cannot repeat. Status history is protected against UPDATE and DELETE by triggers.

Sessions are HTTP-only and SameSite=Lax, and secure in production. Passwords use bcrypt cost 12. Authentication is rate limited. Cross-origin mutations are rejected. Sessions currently use express-session's memory store: restarting signs users out; user accounts, carts, orders and all domain data remain in SQLite. This single-process configuration is suitable for the assignment demo, not a horizontally scaled deployment.

Images accept JPEG/PNG/WebP, inspect decoded content with Sharp, reject oversized or corrupt data, produce WebP large images and thumbnails, and enforce the 1–5 image publishing rule. Demo catalog photos from Unsplash are bundled under public/images; seller-uploaded images are local persistent files. First uploaded image is the main photo. Images can be removed; unpublish first to remove the last photo.

## Persistent production deployment

The supplied Dockerfile is suitable for Railway, Fly.io or a VPS with a persistent disk. Do not deploy this project on a serverless filesystem.

1. Build the image or connect this source directory to a Node/Docker service.
2. Mount a persistent volume at `/data`; set `DATA_DIR=/data`.
3. Set `SESSION_SECRET` to a random secret of at least 32 characters, `NODE_ENV=production`, and the platform's `PORT`.
4. Set `SEED_DEMO=true` for the teacher evaluation database only; seeding happens only if no users exist.
5. Enable the platform's HTTPS domain. One trusted reverse proxy must terminate TLS.
6. Schedule `npm run backup` once daily on the host. Store backups off the service as well, and separately back up `/data/uploads`.
7. Restart/redeploy and verify an uploaded image, account and order still exist.

No hosting account or persistent volume has been provisioned by this project. The production URL and durability check must be completed on a connected compatible host.

## Teacher demo

Register a seller and activate a store. Create a product with three images and publish it. Register a buyer in another browser, search for the product, add it plus an item from another seller, and checkout with an Armenian address. Open the seller dashboard, confirm, ship and deliver. The buyer can now review the delivered item and see the full status history. Repeat at a mobile viewport.

## Scope

Includes the required marketplace features. Excludes card payments, delivery fees, coupons, wishlists, admin moderation, chat and notifications. The site uses English UI with AMD prices and Armenian regions.
